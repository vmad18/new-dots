# Aliases for pre-commit
alias prc='pre-commit'

alias prcau='pre-commit autoupdate'

alias prcr='pre-commit run'
alias prcra='pre-commit run --all-files'
alias prcrf='pre-commit run --files'
